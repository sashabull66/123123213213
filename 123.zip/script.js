// Worker vars:
let worker;
let shouldHasInvalidResultFromPrevSession = false;
let globalDoctype = 'barcode';
const cessionTypes = ['barcode', 'phone', 'card', 'universalPay'];
const activatorSelectorEnum = {
    firstSession: 'firstSession',
    secondSession: 'secondSession',
}
let currentActivatedSession = activatorSelectorEnum['firstSession']


// Worker utils:

// Останавливает и удаляет текущий worker
const killWorker = () => {
    if (!worker) {
        return
    }
    worker.onmessage = null;
    worker?.terminate();
    worker = undefined;
}

// Преобразует строку base64 в byteArray (только в таком виде SE принимает изображения для распознавания)
const convertToByteArray = (base64str) => Uint8Array.from(atob(base64str), (c) => c.charCodeAt(0))

// Преобразует base64str в byteArray и отправляет в worker, может пометить текущее изображение флагом isManuallyUploaded
const loadFile = (base64str, isManuallyUploaded = false) => {
    try {
        const byteArray = convertToByteArray(base64str);

        worker?.postMessage({
            isManuallyUploaded,
            requestType: 'file',
            imageData: byteArray.buffer,
        });
    } catch (e) {
        console.error(e);
    }
};

// Для картинок из стрима камеры
const loadImage = (base64str) => {
    loadFile(base64str, false);
}

// Для ручной загрузки
const uploadPhoto = (base64str) => {
    loadFile(base64str, true);
};

// Отправляет message в window.workerLog, в виде postMessage и в webkit
const postMessageToWebkit = (message) => {
    if (window?.isDevEnv) {
        window?.WorkerLogger?.LogInfo?.({info:'Отправка сообщения в webkit', payload:message});
        postMessage(message);
    }
    if (window?.webkit?.messageHandlers?.callbackHandler?.postMessage) {
        window.webkit.messageHandlers.callbackHandler.postMessage(message);
    }
};

// Создает сессию инстанса SE с указанным docType
const createSession = (docType) => {
    worker?.postMessage({
        requestType: 'createSession',
        data: docType,
    });
};

// Отправляет код активации для инстанса SE
const activate = (code) => {
    worker?.postMessage({
        requestType: 'activationCode',
        session: currentActivatedSession,
        code,
    });
};

/**
* Декодирует строку из Base64 с автоопределением кодировки (UTF-8 / Windows-1251)
* **/
const decodeBase64String = (encodedString) => {
    const binaryData = atob(encodedString);

    const bytes = new Uint8Array(binaryData.length);

    for (let i = 0; i < binaryData.length; i++) {
        bytes[i] = binaryData.charCodeAt(i);
    }

    const utf8String = new TextDecoder('utf-8').decode(bytes);

    const reEncoded = new TextEncoder().encode(utf8String);

    if (reEncoded.length !== bytes.length) {
        try {
            return new TextDecoder('windows-1251').decode(bytes);
        } catch (e) {
            return utf8String;
        }
    }

    return utf8String;
};

// Утилиты для преобразования валидного ответа либы в формат нужный для отправки в smart-camera-api
const convertQrResult = (result) => {
    if (result?.URL?.value_string) {
        if (result.URL.isAccepted === true) {
            return {
                type: 'QR_CODE',
                paymentDetails: false,
                scanData: result.URL.value_string,
            }
        }
    }
    if (result?.bytes?.value_binary) {
        if (result.bytes.isAccepted === true) {
            return {
                type: 'QR_CODE',
                paymentDetails: false,
                scanData: decodeBase64String(result.bytes.value_binary),
            }
        }
    }
}
const convertTelNumberResult = (result) => {
    if (result?.phone_number?.isAccepted === true) {
        return {
            type: 'PHONE',
            paymentDetails: false,
            scanData: result?.phone_number?.value_string,
        };
    }
}
/**
 * Удаляет пробелы из номера карты. Из номера 1234 1234 1234 1234 получается строка 1234123412341234
 * */
const joinCardNumber = (splittedCardNumber) => splittedCardNumber.replace(/ /g, '');

const convertBankCardResult = (result) => {
    if (result?.number?.isAccepted === true) {
        return {
            type: 'CARD',
            paymentDetails: false,
            scanData: joinCardNumber(result?.number?.value_string),
        };
    }
}
const convertPaymentsDetailsResult = (result) => {
    let barcode = 'ST00012';

    if (result?.kpp?.isAccepted === true) {
        barcode += `|KPP=${result?.kpp?.value_string}`;
    }

    if (result?.inn?.isAccepted === true) {
        barcode += `|PayeeINN=${result?.inn?.value_string}`;
    }

    if (result?.rcbic?.isAccepted === true) {
        barcode += `|BIC=${result?.rcbic?.value_string}`;
    }

    if (result?.rus_bank_account?.isAccepted === true) {
        barcode += `|PersonalAcc=${result?.rus_bank_account?.value_string}`;
    }

    if (barcode.length > 7) {
        return {
            type: 'QR_CODE',
            scanData: barcode,
            paymentDetails: true,
        }
    }
}

const convertResult = (result) => {
    const [firstElement] = result?.data;
    switch (firstElement.type) {
        case 'BankCard':
            return convertBankCardResult(firstElement)

        case 'CodeTextLine':
            return convertTelNumberResult(firstElement)

        case 'MatrixBarcode':
            return  convertQrResult(firstElement)

        case 'PaymentDetails':
            return convertPaymentsDetailsResult(firstElement)
    }
}

/**
 * 1. Инициализирует лог в window.workerLog
 * 2. Задает doctype в глобальную переменную (нужно при реактивации)
 * 3. Останавливает и удаляет потенциально уже созданный ранее worker в window.worker
 * 4. Создает в window.worker новый worker и запускает в нем инстанс SE
 * 5. Навешивает на ранее созданный worker слушатель его сообщений
 * @param doctype 'barcode' | 'phone' | 'card' | 'universalPay'
 * */
const initSmartCodeEngine = (doctype) => {
    window?.WorkerLogger?.initWorkerLogger?.();

    if (doctype) {
        globalDoctype = doctype;
    }

    killWorker();

    window?.markActiveBtn?.(globalDoctype)

    const initSmartCodeEngineWorker = (type) => {
        window?.WorkerLogger?.LogInfo?.({ info:`Выполнение createSession с аргументом ${type}`})
        
        if (cessionTypes.includes(type)) {
            worker = new Worker('./smart-code/worker.js');
        } else {
            return
        }

        worker.onmessage = async (msg) => {
            const resultData = msg.data;
            switch (resultData?.requestType) {
                case 'wasmEvent': {
                    if (resultData.data.type === 'ready') {
                        window?.WorkerLogger?.LogInfo?.({ info: `wasmEvent c статусом ready. Производится создание сессии с типом ${type}` })
                        createSession(type);
                    }
                    if (['error', 'processError'].includes(resultData.data.type)) {
                        window?.WorkerLogger?.LogInfo?.({ error: `wasmEvent c ошибкой: ${resultData.data.type}. Производится рестарт worker` })

                        initSmartCodeEngine(globalDoctype);
                    }
                    break;
                }

                case 'result': {
                    if (resultData.isManuallyUploaded && Object.keys(resultData.data).length  === 0) {
                        if (!shouldHasInvalidResultFromPrevSession && globalDoctype === 'universalPay') {
                            shouldHasInvalidResultFromPrevSession = true;
                            window?.WorkerLogger?.LogInfo?.({ info: 'Получен невалидный result после ручной загрузки от первой сессии жду второго невалидного ответа' })
                            break;
                        }

                        const result = JSON.stringify({
                            type: 'scannerResult',
                            status: 'result',
                            payload: [],
                        });

                        shouldHasInvalidResultFromPrevSession = false;
                        window?.WorkerLogger?.LogInfo?.({ info: 'Получен невалидный result после ручной загрузки от двух сессий' })

                        postMessageToWebkit(result);
                    }

                    if (resultData.data.length) {
                        let result

                        if (globalDoctype === 'universalPay') {
                            result = JSON.stringify({
                                type: 'scannerResult',
                                status: 'result',
                                payload: convertResult(resultData),
                            });
                        } else {
                            result = JSON.stringify({
                                type: 'scannerResult',
                                status: 'result',
                                payload: resultData,
                            });
                        }

                        if (result) {
                            postMessageToWebkit(result);
                        }

                        window?.WorkerLogger?.LogInfo?.({ info: 'Получен успешный result c payload. Производится рестарт worker' })
                        initSmartCodeEngine(globalDoctype);

                    }

                    break;
                }

                case 'activated': {
                    const activationResult = JSON.stringify({
                        type: 'scannerResult',
                        status: 'activationSuccessful',
                        payload: null,
                    });
                    window?.applyPositiveCssStyles?.(globalDoctype)

                    postMessageToWebkit(activationResult);

                    break;
                }

                case 'activation':
                case 'secondSessionActivation': {
                    currentActivatedSession = activatorSelectorEnum[resultData?.session]

                    const activationResult = JSON.stringify({
                        type: 'scannerResult',
                        status: 'activationExpired',
                        payload: resultData?.code,
                    });
                    postMessageToWebkit(activationResult);
                    window?.applyNegativeCssStyles?.(resultData?.code);

                    break;
                }
                default:
                    break;
            }
        };
    };

    switch (globalDoctype) {
        case 'barcode':
            initSmartCodeEngineWorker('barcode');
            break;
        case 'phone':
            initSmartCodeEngineWorker('phone');
            break;
        case 'card':
            initSmartCodeEngineWorker('card');
            break;
        case 'universalPay':
            initSmartCodeEngineWorker('universalPay');
            break;
        default:
            window?.WorkerLogger?.LogInfo?.({ error: `Неверно указан docType. Ожидается 'barcode' | 'phone' | 'card' | 'universalPay' а передан '${globalDoctype}'` })
            break
    }
};

// Интерфейс для взаимодействия для IOS AM приложения
window.scanner = {
    createSession: initSmartCodeEngine,
    uploadPhoto,
    loadImage,
    activate,
};
