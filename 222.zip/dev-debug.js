const output = document.getElementById('output');
const copyBtn = document.getElementById('copyBtn');
const pastBtn = document.getElementById('pastBtn');
const pastUrlQrBtn = document.getElementById('pastQrBtn');
const pastBaseQrBtnBtn = document.getElementById('pastBaseQrBtn');
const pastInvalidQrBtn = document.getElementById('pastInvalidQrBtn');
const pastInvalidImgBtn = document.getElementById('pastInvalidImgBtn');
const pastPaymentDetailsBtn = document.getElementById('pastPaymentDetails');
const pastPaymentDetails2Btn = document.getElementById('pastPaymentDetails2');
const pastTelNumBtn = document.getElementById('pastTelNumBtn');
const pastBankCardBtn = document.getElementById('pastBankCard');
const pastFromClipboardBtn = document.getElementById('pastFromClipboard');
const notActivated = document.getElementById('notActivated');
const tryActivate = document.getElementById('tryActivate');
const body = document.querySelector('body');

window.isDevEnv = true

window.markActiveBtn = (doctype) => {
    cessionTypes.forEach(type => {
        document.getElementById(type).style.backgroundColor = 'buttonface'
    })
    if (cessionTypes.includes(doctype)) {
        document.getElementById(doctype).style.backgroundColor = 'green'
    }
}

window.applyPositiveCssStyles = (globalDoctype) => {
    body.style.backgroundColor = 'green'
    copyBtn.onclick = null
    copyBtn.style.display = 'none'
    pastBtn.style.display = 'none'
    if (globalDoctype === 'barcode' || globalDoctype === 'universalPay') {
        pastUrlQrBtn.style.display = 'block'
        pastBaseQrBtnBtn.style.display = 'block'
        pastInvalidQrBtn.style.display = 'block'
    }
    if (globalDoctype === 'phone' || globalDoctype === 'universalPay') {
        pastTelNumBtn.style.display = 'block'
    }
    if (globalDoctype === 'card' || globalDoctype === 'universalPay') {
        pastBankCardBtn.style.display = 'block'
    }
    if (globalDoctype === 'universalPay') {
        pastPaymentDetailsBtn.style.display = 'block'
        pastPaymentDetails2Btn.style.display = 'block'
    }
    pastFromClipboardBtn.style.display = 'block'
    pastInvalidImgBtn.style.display = 'block'
}

window.applyNegativeCssStyles = (code) => {
    body.style.backgroundColor = 'red'
    copyBtn.onclick = () => {
        window.navigator.clipboard.writeText(code);
    }
    copyBtn.style.display = 'block'
    pastBtn.style.display = 'block'
    pastUrlQrBtn.style.display = 'none'
    pastBaseQrBtnBtn.style.display = 'none'
    pastInvalidQrBtn.style.display = 'none'
    pastPaymentDetailsBtn.style.display = 'none'
    pastPaymentDetails2Btn.style.display = 'none'
    pastTelNumBtn.style.display = 'none'
    pastBankCardBtn.style.display = 'none'
    pastFromClipboardBtn.style.display = 'none'
    pastInvalidImgBtn.style.display = 'none'
}

window.activateLibrary = (code) => {
    const url = 'https://alfa-proxy.onrender.com/api/alfa-qr';

    const body = JSON.stringify({ code });

    tryActivate.style.display = 'block';


    return fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: body
    })
        .then(response => {
            tryActivate.style.display = 'none';
            notActivated.style.display = 'none';
            return response.json()
        })
        .catch(error => {
            tryActivate.style.display = 'none';
            notActivated.style.display = 'block';
            console.error('Error:', error)
        });
}

// UI manual debug listeners
window.addEventListener('message', (e) => {
    output.innerText = e.data;
});

pastBtn.addEventListener('click', async () => {
    const code = await window.navigator.clipboard.readText();
    activate(code);
});

pastUrlQrBtn.addEventListener('click', async () => {
    loadImage(mocks.qrCodeUrl);
});
pastInvalidQrBtn.addEventListener('click', async () => {
    loadImage(mocks.invalidQr);
});
pastBaseQrBtnBtn.addEventListener('click', async () => {
    loadImage(mocks.qrCodeBinary);
});
pastPaymentDetailsBtn.addEventListener('click', async () => {
    loadImage(mocks.paymentDetails);
});
pastPaymentDetails2Btn.addEventListener('click', async () => {
    loadImage(mocks.paymentDetails2);
});
pastTelNumBtn.addEventListener('click', async () => {
    loadImage(mocks.telNumber);
});
pastBankCardBtn.addEventListener('click', async () => {
    loadImage(mocks.bankCard);
});
pastInvalidImgBtn.addEventListener('click', async () => {
    uploadPhoto(mocks.invalidData);
});
pastFromClipboardBtn.addEventListener('click', async () => {
    const cnt = await window.navigator.clipboard.readText();
    const trimmedContent = cnt.split(',')[1];
    loadImage(trimmedContent || cnt);
});

window.WorkerLogger = {
    initWorkerLogger() {
        if (!window.workerLog) {
            window.workerLog = [];
        }
    },
    LogInfo(data) {
        window?.workerLog?.push(data)
    }
}