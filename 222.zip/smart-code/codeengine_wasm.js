var SmartCodeEngine = (() => {
    var _scriptName = typeof document != 'undefined' ? document.currentScript?.src : undefined;

    return function (moduleArg = {}) {
        var moduleRtn;

        var n = moduleArg,
            aa,
            ba,
            ca = new Promise((a, b) => {
                aa = a;
                ba = b;
            }),
            da = 'object' == typeof window,
            ea = 'undefined' != typeof WorkerGlobalScope,
            fa = Object.assign({}, n),
            p = '',
            ia,
            ja;
        if (da || ea)
            ea
                ? (p = self.location.href)
                : 'undefined' != typeof document &&
                  document.currentScript &&
                  (p = document.currentScript.src),
                _scriptName && (p = _scriptName),
                p.startsWith('blob:')
                    ? (p = '')
                    : (p = p.substr(0, p.replace(/[?#].*/, '').lastIndexOf('/') + 1)),
                ea &&
                    (ja = (a) => {
                        var b = new XMLHttpRequest();
                        b.open('GET', a, !1);
                        b.responseType = 'arraybuffer';
                        b.send(null);
                        return new Uint8Array(b.response);
                    }),
                (ia = async (a) => {
                    a = await fetch(a, { credentials: 'same-origin' });
                    if (a.ok) return a.arrayBuffer();
                    throw Error(a.status + ' : ' + a.url);
                });
        var ka = console.log.bind(console),
            q = n.printErr || console.error.bind(console);
        Object.assign(n, fa);
        fa = null;
        var la,
            ma = !1,
            r,
            u,
            x,
            z,
            A,
            C,
            na,
            oa;
        function pa() {
            var a = la.buffer;
            n.HEAP8 = r = new Int8Array(a);
            n.HEAP16 = x = new Int16Array(a);
            n.HEAPU8 = u = new Uint8Array(a);
            n.HEAPU16 = z = new Uint16Array(a);
            n.HEAP32 = A = new Int32Array(a);
            n.HEAPU32 = C = new Uint32Array(a);
            n.HEAPF32 = na = new Float32Array(a);
            n.HEAPF64 = oa = new Float64Array(a);
        }
        var qa = [],
            ra = [],
            sa = [],
            F = 0,
            G = null;
        function H(a) {
            a = 'Aborted(' + a + ')';
            q(a);
            ma = !0;
            a = new WebAssembly.RuntimeError(a + '. Build with -sASSERTIONS for more info.');
            ba(a);
            throw a;
        }
        var ta = (a) => a.startsWith('data:application/octet-stream;base64,'),
            ua;
        async function va(a) {
            try {
                var b = await ia(a);
                return new Uint8Array(b);
            } catch {}
            if (ja) a = ja(a);
            else throw 'both async and sync fetching of the wasm failed';
            return a;
        }
        async function wa(a, b) {
            try {
                var c = await va(a);
                return await WebAssembly.instantiate(c, b);
            } catch (d) {
                q(`failed to asynchronously prepare wasm: ${d}`), H(d);
            }
        }
        async function xa(a) {
            var b = ua;
            if (
                'function' == typeof WebAssembly.instantiateStreaming &&
                !ta(b) &&
                'function' == typeof fetch
            )
                try {
                    var c = fetch(b, { credentials: 'same-origin' });
                    return await WebAssembly.instantiateStreaming(c, a);
                } catch (d) {
                    q(`wasm streaming compile failed: ${d}`),
                        q('falling back to ArrayBuffer instantiation');
                }
            return wa(b, a);
        }
        var J, ya;
        class za {
            name = 'ExitStatus';
            constructor(a) {
                this.message = `Program terminated with exit(${a})`;
                this.status = a;
            }
        }
        var Aa = [],
            Ba = 0,
            K = 0;
        class Ca {
            constructor(a) {
                this.zd = a;
                this.cd = a - 24;
            }
        }
        var Ea = (a) => {
                var b = K;
                if (!b) return L(0), 0;
                var c = new Ca(b);
                C[(c.cd + 16) >> 2] = b;
                var d = C[(c.cd + 4) >> 2];
                if (!d) return L(0), b;
                for (var e of a) {
                    if (0 === e || e === d) break;
                    if (Da(e, d, c.cd + 16)) return L(e), b;
                }
                L(d);
                return b;
            },
            Fa = 'undefined' != typeof TextDecoder ? new TextDecoder() : void 0,
            Ga = (a, b = 0, c = NaN) => {
                var d = b + c;
                for (c = b; a[c] && !(c >= d); ) ++c;
                if (16 < c - b && a.buffer && Fa) return Fa.decode(a.subarray(b, c));
                for (d = ''; b < c; ) {
                    var e = a[b++];
                    if (e & 128) {
                        var f = a[b++] & 63;
                        if (192 == (e & 224)) d += String.fromCharCode(((e & 31) << 6) | f);
                        else {
                            var g = a[b++] & 63;
                            e =
                                224 == (e & 240)
                                    ? ((e & 15) << 12) | (f << 6) | g
                                    : ((e & 7) << 18) | (f << 12) | (g << 6) | (a[b++] & 63);
                            65536 > e
                                ? (d += String.fromCharCode(e))
                                : ((e -= 65536),
                                  (d += String.fromCharCode(
                                      55296 | (e >> 10),
                                      56320 | (e & 1023),
                                  )));
                        }
                    } else d += String.fromCharCode(e);
                }
                return d;
            },
            Ha = {},
            Ia = (a) => {
                for (; a.length; ) {
                    var b = a.pop();
                    a.pop()(b);
                }
            };
        function Ja(a) {
            return this.fromWireType(C[a >> 2]);
        }
        var M = {},
            N = {},
            Ka = {},
            La,
            P = (a, b, c) => {
                function d(h) {
                    h = c(h);
                    if (h.length !== a.length) throw new La('Mismatched type converter count');
                    for (var k = 0; k < a.length; ++k) O(a[k], h[k]);
                }
                a.forEach((h) => (Ka[h] = b));
                var e = Array(b.length),
                    f = [],
                    g = 0;
                b.forEach((h, k) => {
                    N.hasOwnProperty(h)
                        ? (e[k] = N[h])
                        : (f.push(h),
                          M.hasOwnProperty(h) || (M[h] = []),
                          M[h].push(() => {
                              e[k] = N[h];
                              ++g;
                              g === f.length && d(e);
                          }));
                });
                0 === f.length && d(e);
            },
            Ma,
            Q = (a) => {
                for (var b = ''; u[a]; ) b += Ma[u[a++]];
                return b;
            },
            R,
            Na = (a) => {
                throw new R(a);
            };
        function Pa(a, b, c = {}) {
            var d = b.name;
            if (!a) throw new R(`type "${d}" must have a positive integer typeid pointer`);
            if (N.hasOwnProperty(a)) {
                if (c.Kd) return;
                throw new R(`Cannot register type '${d}' twice`);
            }
            N[a] = b;
            delete Ka[a];
            M.hasOwnProperty(a) && ((b = M[a]), delete M[a], b.forEach((e) => e()));
        }
        function O(a, b, c = {}) {
            return Pa(a, b, c);
        }
        var Qa = (a) => {
                throw new R(a.bd.ed.dd.name + ' instance already deleted');
            },
            Ra = !1,
            Sa = () => {},
            Ta = (a, b, c) => {
                if (b === c) return a;
                if (void 0 === c.hd) return null;
                a = Ta(a, b, c.hd);
                return null === a ? null : c.Dd(a);
            },
            Ua = {},
            Va = {},
            Wa = (a, b) => {
                if (void 0 === b) throw new R('ptr should not be undefined');
                for (; a.hd; ) (b = a.sd(b)), (a = a.hd);
                return Va[b];
            },
            Ya = (a, b) => {
                if (!b.ed || !b.cd) throw new La('makeClassHandle requires ptr and ptrType');
                if (!!b.kd !== !!b.gd)
                    throw new La('Both smartPtrType and smartPtr must be specified');
                b.count = { value: 1 };
                return Xa(Object.create(a, { bd: { value: b, writable: !0 } }));
            },
            Xa = (a) => {
                if ('undefined' === typeof FinalizationRegistry) return (Xa = (b) => b), a;
                Ra = new FinalizationRegistry((b) => {
                    b = b.bd;
                    --b.count.value;
                    0 === b.count.value && (b.gd ? b.kd.md(b.gd) : b.ed.dd.md(b.cd));
                });
                Xa = (b) => {
                    var c = b.bd;
                    c.gd && Ra.register(b, { bd: c }, b);
                    return b;
                };
                Sa = (b) => {
                    Ra.unregister(b);
                };
                return Xa(a);
            },
            Za = [];
        function $a() {}
        var ab = (a, b) => Object.defineProperty(b, 'name', { value: a }),
            bb = (a, b, c) => {
                if (void 0 === a[b].fd) {
                    var d = a[b];
                    a[b] = function (...e) {
                        if (!a[b].fd.hasOwnProperty(e.length))
                            throw new R(
                                `Function '${c}' called with an invalid number of arguments (${e.length}) - expects one of (${a[b].fd})!`,
                            );
                        return a[b].fd[e.length].apply(this, e);
                    };
                    a[b].fd = [];
                    a[b].fd[d.pd] = d;
                }
            },
            cb = (a, b, c) => {
                if (n.hasOwnProperty(a)) {
                    if (void 0 === c || (void 0 !== n[a].fd && void 0 !== n[a].fd[c]))
                        throw new R(`Cannot register public name '${a}' twice`);
                    bb(n, a, a);
                    if (n[a].fd.hasOwnProperty(c))
                        throw new R(
                            `Cannot register multiple overloads of a function with the same number of arguments (${c})!`,
                        );
                    n[a].fd[c] = b;
                } else (n[a] = b), (n[a].pd = c);
            },
            db = (a) => {
                a = a.replace(/[^a-zA-Z0-9_]/g, '$');
                var b = a.charCodeAt(0);
                return 48 <= b && 57 >= b ? `_${a}` : a;
            };
        function eb(a, b, c, d, e, f, g, h) {
            this.name = a;
            this.constructor = b;
            this.od = c;
            this.md = d;
            this.hd = e;
            this.Fd = f;
            this.sd = g;
            this.Dd = h;
            this.Md = [];
        }
        var fb = (a, b, c) => {
            for (; b !== c; ) {
                if (!b.sd)
                    throw new R(
                        `Expected null or instance of ${c.name}, got an instance of ${b.name}`,
                    );
                a = b.sd(a);
                b = b.hd;
            }
            return a;
        };
        function gb(a, b) {
            if (null === b) {
                if (this.vd) throw new R(`null is not a valid ${this.name}`);
                return 0;
            }
            if (!b.bd) throw new R(`Cannot pass "${hb(b)}" as a ${this.name}`);
            if (!b.bd.cd)
                throw new R(`Cannot pass deleted object as a pointer of type ${this.name}`);
            return fb(b.bd.cd, b.bd.ed.dd, this.dd);
        }
        function ib(a, b) {
            if (null === b) {
                if (this.vd) throw new R(`null is not a valid ${this.name}`);
                if (this.ud) {
                    var c = this.wd();
                    null !== a && a.push(this.md, c);
                    return c;
                }
                return 0;
            }
            if (!b || !b.bd) throw new R(`Cannot pass "${hb(b)}" as a ${this.name}`);
            if (!b.bd.cd)
                throw new R(`Cannot pass deleted object as a pointer of type ${this.name}`);
            if (!this.td && b.bd.ed.td)
                throw new R(
                    `Cannot convert argument of type ${b.bd.kd ? b.bd.kd.name : b.bd.ed.name} to parameter type ${this.name}`,
                );
            c = fb(b.bd.cd, b.bd.ed.dd, this.dd);
            if (this.ud) {
                if (void 0 === b.bd.gd)
                    throw new R('Passing raw pointer to smart pointer is illegal');
                switch (this.Rd) {
                    case 0:
                        if (b.bd.kd === this) c = b.bd.gd;
                        else
                            throw new R(
                                `Cannot convert argument of type ${b.bd.kd ? b.bd.kd.name : b.bd.ed.name} to parameter type ${this.name}`,
                            );
                        break;
                    case 1:
                        c = b.bd.gd;
                        break;
                    case 2:
                        if (b.bd.kd === this) c = b.bd.gd;
                        else {
                            var d = b.clone();
                            c = this.Nd(
                                c,
                                jb(() => d['delete']()),
                            );
                            null !== a && a.push(this.md, c);
                        }
                        break;
                    default:
                        throw new R('Unsupporting sharing policy');
                }
            }
            return c;
        }
        function kb(a, b) {
            if (null === b) {
                if (this.vd) throw new R(`null is not a valid ${this.name}`);
                return 0;
            }
            if (!b.bd) throw new R(`Cannot pass "${hb(b)}" as a ${this.name}`);
            if (!b.bd.cd)
                throw new R(`Cannot pass deleted object as a pointer of type ${this.name}`);
            if (b.bd.ed.td)
                throw new R(
                    `Cannot convert argument of type ${b.bd.ed.name} to parameter type ${this.name}`,
                );
            return fb(b.bd.cd, b.bd.ed.dd, this.dd);
        }
        function lb(a, b, c, d, e, f, g, h, k, l, m) {
            this.name = a;
            this.dd = b;
            this.vd = c;
            this.td = d;
            this.ud = e;
            this.Ld = f;
            this.Rd = g;
            this.Bd = h;
            this.wd = k;
            this.Nd = l;
            this.md = m;
            e || void 0 !== b.hd
                ? (this.toWireType = ib)
                : ((this.toWireType = d ? gb : kb), (this.jd = null));
        }
        var mb = (a, b, c) => {
                if (!n.hasOwnProperty(a)) throw new La('Replacing nonexistent public symbol');
                void 0 !== n[a].fd && void 0 !== c ? (n[a].fd[c] = b) : ((n[a] = b), (n[a].pd = c));
            },
            nb = [],
            ob,
            S = (a) => {
                var b = nb[a];
                b || (a >= nb.length && (nb.length = a + 1), (nb[a] = b = ob.get(a)));
                return b;
            },
            pb = (a, b, c = []) => {
                a.includes('j')
                    ? ((a = a.replace(/p/g, 'i')), (b = (0, n['dynCall_' + a])(b, ...c)))
                    : (b = S(b)(...c));
                return b;
            },
            qb =
                (a, b) =>
                (...c) =>
                    pb(a, b, c),
            T = (a, b) => {
                a = Q(a);
                var c = a.includes('j') ? qb(a, b) : S(b);
                if ('function' != typeof c)
                    throw new R(`unknown function pointer with signature ${a}: ${b}`);
                return c;
            },
            rb,
            tb = (a) => {
                a = sb(a);
                var b = Q(a);
                U(a);
                return b;
            },
            ub = (a, b) => {
                function c(f) {
                    e[f] || N[f] || (Ka[f] ? Ka[f].forEach(c) : (d.push(f), (e[f] = !0)));
                }
                var d = [],
                    e = {};
                b.forEach(c);
                throw new rb(`${a}: ` + d.map(tb).join([', ']));
            },
            vb = (a, b) => {
                for (var c = [], d = 0; d < a; d++) c.push(C[(b + 4 * d) >> 2]);
                return c;
            };
        function xb(a) {
            for (var b = 1; b < a.length; ++b) if (null !== a[b] && void 0 === a[b].jd) return !0;
            return !1;
        }
        function yb(a) {
            var b = Function;
            if (!(b instanceof Function))
                throw new TypeError(
                    `new_ called with constructor type ${typeof b} which is not a function`,
                );
            var c = ab(b.name || 'unknownFunctionName', function () {});
            c.prototype = b.prototype;
            c = new c();
            a = b.apply(c, a);
            return a instanceof Object ? a : c;
        }
        function zb(a, b, c, d, e, f) {
            var g = b.length;
            if (2 > g)
                throw new R(
                    "argTypes array size mismatch! Must at least get return value and 'this' types!",
                );
            var h = null !== b[1] && null !== c,
                k = xb(b);
            c = 'void' !== b[0].name;
            d = [a, Na, d, e, Ia, b[0], b[1]];
            for (e = 0; e < g - 2; ++e) d.push(b[e + 2]);
            if (!k) for (e = h ? 1 : 2; e < b.length; ++e) null !== b[e].jd && d.push(b[e].jd);
            k = xb(b);
            e = b.length - 2;
            var l = [],
                m = ['fn'];
            h && m.push('thisWired');
            for (g = 0; g < e; ++g) l.push(`arg${g}`), m.push(`arg${g}Wired`);
            l = l.join(',');
            m = m.join(',');
            l = `return function (${l}) {\n`;
            k && (l += 'var destructors = [];\n');
            var t = k ? 'destructors' : 'null',
                v =
                    'humanName throwBindingError invoker fn runDestructors retType classParam'.split(
                        ' ',
                    );
            h && (l += `var thisWired = classParam['toWireType'](${t}, this);\n`);
            for (g = 0; g < e; ++g)
                (l += `var arg${g}Wired = argType${g}['toWireType'](${t}, arg${g});\n`),
                    v.push(`argType${g}`);
            l += (c || f ? 'var rv = ' : '') + `invoker(${m});\n`;
            if (k) l += 'runDestructors(destructors);\n';
            else
                for (g = h ? 1 : 2; g < b.length; ++g)
                    (f = 1 === g ? 'thisWired' : 'arg' + (g - 2) + 'Wired'),
                        null !== b[g].jd && ((l += `${f}_dtor(${f});\n`), v.push(`${f}_dtor`));
            c && (l += "var ret = retType['fromWireType'](rv);\nreturn ret;\n");
            let [w, y] = [v, l + '}\n'];
            w.push(y);
            b = yb(w)(...d);
            return ab(a, b);
        }
        var Ab = (a) => {
                a = a.trim();
                const b = a.indexOf('(');
                return -1 !== b ? a.substr(0, b) : a;
            },
            Bb = [],
            V = [],
            jb = (a) => {
                switch (a) {
                    case void 0:
                        return 2;
                    case null:
                        return 4;
                    case !0:
                        return 6;
                    case !1:
                        return 8;
                    default:
                        const b = Bb.pop() || V.length;
                        V[b] = a;
                        V[b + 1] = 1;
                        return b;
                }
            },
            Cb = {
                name: 'emscripten::val',
                fromWireType: (a) => {
                    if (!a) throw new R('Cannot use deleted val. handle = ' + a);
                    var b = V[a];
                    9 < a && 0 === --V[a + 1] && ((V[a] = void 0), Bb.push(a));
                    return b;
                },
                toWireType: (a, b) => jb(b),
                ld: 8,
                readValueFromPointer: Ja,
                jd: null,
            },
            Db = (a, b, c) => {
                switch (b) {
                    case 1:
                        return c
                            ? function (d) {
                                  return this.fromWireType(r[d]);
                              }
                            : function (d) {
                                  return this.fromWireType(u[d]);
                              };
                    case 2:
                        return c
                            ? function (d) {
                                  return this.fromWireType(x[d >> 1]);
                              }
                            : function (d) {
                                  return this.fromWireType(z[d >> 1]);
                              };
                    case 4:
                        return c
                            ? function (d) {
                                  return this.fromWireType(A[d >> 2]);
                              }
                            : function (d) {
                                  return this.fromWireType(C[d >> 2]);
                              };
                    default:
                        throw new TypeError(`invalid integer width (${b}): ${a}`);
                }
            },
            Eb = (a) => {
                var b = N[a];
                if (void 0 === b) throw ((a = `${'enum'} has unknown type ${tb(a)}`), new R(a));
                return b;
            },
            hb = (a) => {
                if (null === a) return 'null';
                var b = typeof a;
                return 'object' === b || 'array' === b || 'function' === b ? a.toString() : '' + a;
            },
            Fb = (a, b) => {
                switch (b) {
                    case 4:
                        return function (c) {
                            return this.fromWireType(na[c >> 2]);
                        };
                    case 8:
                        return function (c) {
                            return this.fromWireType(oa[c >> 3]);
                        };
                    default:
                        throw new TypeError(`invalid float width (${b}): ${a}`);
                }
            },
            Gb = (a, b, c) => {
                switch (b) {
                    case 1:
                        return c ? (d) => r[d] : (d) => u[d];
                    case 2:
                        return c ? (d) => x[d >> 1] : (d) => z[d >> 1];
                    case 4:
                        return c ? (d) => A[d >> 2] : (d) => C[d >> 2];
                    default:
                        throw new TypeError(`invalid integer width (${b}): ${a}`);
                }
            },
            Hb = (a, b, c) => {
                var d = u;
                if (0 < c) {
                    c = b + c - 1;
                    for (var e = 0; e < a.length; ++e) {
                        var f = a.charCodeAt(e);
                        if (55296 <= f && 57343 >= f) {
                            var g = a.charCodeAt(++e);
                            f = (65536 + ((f & 1023) << 10)) | (g & 1023);
                        }
                        if (127 >= f) {
                            if (b >= c) break;
                            d[b++] = f;
                        } else {
                            if (2047 >= f) {
                                if (b + 1 >= c) break;
                                d[b++] = 192 | (f >> 6);
                            } else {
                                if (65535 >= f) {
                                    if (b + 2 >= c) break;
                                    d[b++] = 224 | (f >> 12);
                                } else {
                                    if (b + 3 >= c) break;
                                    d[b++] = 240 | (f >> 18);
                                    d[b++] = 128 | ((f >> 12) & 63);
                                }
                                d[b++] = 128 | ((f >> 6) & 63);
                            }
                            d[b++] = 128 | (f & 63);
                        }
                    }
                    d[b] = 0;
                }
            },
            Ib = 'undefined' != typeof TextDecoder ? new TextDecoder('utf-16le') : void 0,
            Jb = (a, b) => {
                var c = a >> 1;
                for (var d = c + b / 2; !(c >= d) && z[c]; ) ++c;
                c <<= 1;
                if (32 < c - a && Ib) return Ib.decode(u.subarray(a, c));
                c = '';
                for (d = 0; !(d >= b / 2); ++d) {
                    var e = x[(a + 2 * d) >> 1];
                    if (0 == e) break;
                    c += String.fromCharCode(e);
                }
                return c;
            },
            Kb = (a, b, c) => {
                c ??= 2147483647;
                if (2 > c) return 0;
                c -= 2;
                var d = b;
                c = c < 2 * a.length ? c / 2 : a.length;
                for (var e = 0; e < c; ++e) (x[b >> 1] = a.charCodeAt(e)), (b += 2);
                x[b >> 1] = 0;
                return b - d;
            },
            Lb = (a) => 2 * a.length,
            Mb = (a, b) => {
                for (var c = 0, d = ''; !(c >= b / 4); ) {
                    var e = A[(a + 4 * c) >> 2];
                    if (0 == e) break;
                    ++c;
                    65536 <= e
                        ? ((e -= 65536),
                          (d += String.fromCharCode(55296 | (e >> 10), 56320 | (e & 1023))))
                        : (d += String.fromCharCode(e));
                }
                return d;
            },
            Nb = (a, b, c) => {
                c ??= 2147483647;
                if (4 > c) return 0;
                var d = b;
                c = d + c - 4;
                for (var e = 0; e < a.length; ++e) {
                    var f = a.charCodeAt(e);
                    if (55296 <= f && 57343 >= f) {
                        var g = a.charCodeAt(++e);
                        f = (65536 + ((f & 1023) << 10)) | (g & 1023);
                    }
                    A[b >> 2] = f;
                    b += 4;
                    if (b + 4 > c) break;
                }
                A[b >> 2] = 0;
                return b - d;
            },
            Ob = (a) => {
                for (var b = 0, c = 0; c < a.length; ++c) {
                    var d = a.charCodeAt(c);
                    55296 <= d && 57343 >= d && ++c;
                    b += 4;
                }
                return b;
            },
            Pb = {},
            Qb = (a) => {
                if (!ma)
                    try {
                        a();
                    } catch (b) {
                        if (!(b instanceof za || 'unwind' == b)) throw b;
                    }
            },
            Rb = {},
            Tb = () => {
                if (!Sb) {
                    var a = {
                            USER: 'web_user',
                            LOGNAME: 'web_user',
                            PATH: '/',
                            PWD: '/',
                            HOME: '/home/web_user',
                            LANG:
                                (
                                    ('object' == typeof navigator &&
                                        navigator.languages &&
                                        navigator.languages[0]) ||
                                    'C'
                                ).replace('-', '_') + '.UTF-8',
                            _: './this.program',
                        },
                        b;
                    for (b in Rb) void 0 === Rb[b] ? delete a[b] : (a[b] = Rb[b]);
                    var c = [];
                    for (b in a) c.push(`${b}=${a[b]}`);
                    Sb = c;
                }
                return Sb;
            },
            Sb,
            Ub = [null, [], []],
            Vb = () => {
                if ('object' == typeof crypto && 'function' == typeof crypto.getRandomValues)
                    return (a) => crypto.getRandomValues(a);
                H('initRandomDevice');
            },
            Wb = (a) => (Wb = Vb())(a);
        La = n.InternalError = class extends Error {
            constructor(a) {
                super(a);
                this.name = 'InternalError';
            }
        };
        for (var Xb = Array(256), Yb = 0; 256 > Yb; ++Yb) Xb[Yb] = String.fromCharCode(Yb);
        Ma = Xb;
        R = n.BindingError = class extends Error {
            constructor(a) {
                super(a);
                this.name = 'BindingError';
            }
        };
        Object.assign($a.prototype, {
            isAliasOf: function (a) {
                if (!(this instanceof $a && a instanceof $a)) return !1;
                var b = this.bd.ed.dd,
                    c = this.bd.cd;
                a.bd = a.bd;
                var d = a.bd.ed.dd;
                for (a = a.bd.cd; b.hd; ) (c = b.sd(c)), (b = b.hd);
                for (; d.hd; ) (a = d.sd(a)), (d = d.hd);
                return b === d && c === a;
            },
            clone: function () {
                this.bd.cd || Qa(this);
                if (this.bd.rd) return (this.bd.count.value += 1), this;
                var a = Xa,
                    b = Object,
                    c = b.create,
                    d = Object.getPrototypeOf(this),
                    e = this.bd;
                a = a(
                    c.call(b, d, {
                        bd: {
                            value: {
                                count: e.count,
                                qd: e.qd,
                                rd: e.rd,
                                cd: e.cd,
                                ed: e.ed,
                                gd: e.gd,
                                kd: e.kd,
                            },
                        },
                    }),
                );
                a.bd.count.value += 1;
                a.bd.qd = !1;
                return a;
            },
            ['delete']() {
                this.bd.cd || Qa(this);
                if (this.bd.qd && !this.bd.rd) throw new R('Object already scheduled for deletion');
                Sa(this);
                var a = this.bd;
                --a.count.value;
                0 === a.count.value && (a.gd ? a.kd.md(a.gd) : a.ed.dd.md(a.cd));
                this.bd.rd || ((this.bd.gd = void 0), (this.bd.cd = void 0));
            },
            isDeleted: function () {
                return !this.bd.cd;
            },
            deleteLater: function () {
                this.bd.cd || Qa(this);
                if (this.bd.qd && !this.bd.rd) throw new R('Object already scheduled for deletion');
                Za.push(this);
                this.bd.qd = !0;
                return this;
            },
        });
        Object.assign(lb.prototype, {
            Gd(a) {
                this.Bd && (a = this.Bd(a));
                return a;
            },
            yd(a) {
                this.md?.(a);
            },
            ld: 8,
            readValueFromPointer: Ja,
            fromWireType: function (a) {
                function b() {
                    return this.ud
                        ? Ya(this.dd.od, { ed: this.Ld, cd: c, kd: this, gd: a })
                        : Ya(this.dd.od, { ed: this, cd: a });
                }
                var c = this.Gd(a);
                if (!c) return this.yd(a), null;
                var d = Wa(this.dd, c);
                if (void 0 !== d) {
                    if (0 === d.bd.count.value) return (d.bd.cd = c), (d.bd.gd = a), d.clone();
                    d = d.clone();
                    this.yd(a);
                    return d;
                }
                d = this.dd.Fd(c);
                d = Ua[d];
                if (!d) return b.call(this);
                d = this.td ? d.Cd : d.pointerType;
                var e = Ta(c, this.dd, d.dd);
                return null === e
                    ? b.call(this)
                    : this.ud
                      ? Ya(d.dd.od, { ed: d, cd: e, kd: this, gd: a })
                      : Ya(d.dd.od, { ed: d, cd: e });
            },
        });
        rb = n.UnboundTypeError = ((a, b) => {
            var c = ab(b, function (d) {
                this.name = b;
                this.message = d;
                d = Error(d).stack;
                void 0 !== d &&
                    (this.stack = this.toString() + '\n' + d.replace(/^Error(:[^\n]*)?\n/, ''));
            });
            c.prototype = Object.create(a.prototype);
            c.prototype.constructor = c;
            c.prototype.toString = function () {
                return void 0 === this.message ? this.name : `${this.name}: ${this.message}`;
            };
            return c;
        })(Error, 'UnboundTypeError');
        V.push(0, 1, void 0, 1, null, 1, !0, 1, !1, 1);
        n.count_emval_handles = () => V.length / 2 - 5 - Bb.length;
        var be = {
                p: (a) => {
                    var b = new Ca(a);
                    0 == r[b.cd + 12] && ((r[b.cd + 12] = 1), Ba--);
                    r[b.cd + 13] = 0;
                    Aa.push(b);
                    Zb(a);
                    return $b(a);
                },
                Y: () =>
                    H('Unexpected exception thrown, this is not properly supported - aborting'),
                B: () => {
                    W(0, 0);
                    var a = Aa.pop();
                    ac(a.zd);
                    K = 0;
                },
                a: () => Ea([]),
                i: (a) => Ea([a]),
                o: (a, b) => Ea([a, b]),
                Rb: (a, b, c) => Ea([a, b, c]),
                Ia: () => {
                    var a = Aa.pop();
                    a || H('no exception to throw');
                    var b = a.zd;
                    0 == r[a.cd + 13] && (Aa.push(a), (r[a.cd + 13] = 1), (r[a.cd + 12] = 0), Ba++);
                    K = b;
                    throw K;
                },
                n: (a, b, c) => {
                    var d = new Ca(a);
                    C[(d.cd + 16) >> 2] = 0;
                    C[(d.cd + 4) >> 2] = b;
                    C[(d.cd + 8) >> 2] = c;
                    K = a;
                    Ba++;
                    throw K;
                },
                gb: () => Ba,
                h: (a) => {
                    K ||= a;
                    throw K;
                },
                Ha: function () {
                    return 0;
                },
                sb: () => {},
                ub: function () {
                    return 0;
                },
                qb: () => {},
                mb: () => {},
                pb: () => {},
                sa: function () {},
                rb: () => {},
                kb: () => {},
                vb: () => H(''),
                xb: (a) => {
                    var b = Ha[a];
                    delete Ha[a];
                    var c = b.wd,
                        d = b.md,
                        e = b.Ad,
                        f = e.map((g) => g.Jd).concat(e.map((g) => g.Pd));
                    P([a], f, (g) => {
                        var h = {};
                        e.forEach((k, l) => {
                            var m = g[l],
                                t = k.Hd,
                                v = k.Id,
                                w = g[l + e.length],
                                y = k.Od,
                                B = k.Qd;
                            h[k.Ed] = {
                                read: (D) => m.fromWireType(t(v, D)),
                                write: (D, I) => {
                                    var E = [];
                                    y(B, D, w.toWireType(E, I));
                                    Ia(E);
                                },
                            };
                        });
                        return [
                            {
                                name: b.name,
                                fromWireType: (k) => {
                                    var l = {},
                                        m;
                                    for (m in h) l[m] = h[m].read(k);
                                    d(k);
                                    return l;
                                },
                                toWireType: (k, l) => {
                                    for (var m in h)
                                        if (!(m in l)) throw new TypeError(`Missing field: "${m}"`);
                                    var t = c();
                                    for (m in h) h[m].write(t, l[m]);
                                    null !== k && k.push(d, t);
                                    return t;
                                },
                                ld: 8,
                                readValueFromPointer: Ja,
                                jd: d,
                            },
                        ];
                    });
                },
                Qb: () => {},
                ab: (a, b, c, d) => {
                    b = Q(b);
                    O(a, {
                        name: b,
                        fromWireType: function (e) {
                            return !!e;
                        },
                        toWireType: function (e, f) {
                            return f ? c : d;
                        },
                        ld: 8,
                        readValueFromPointer: function (e) {
                            return this.fromWireType(u[e]);
                        },
                        jd: null,
                    });
                },
                C: (a, b, c, d, e, f, g, h, k, l, m, t, v) => {
                    m = Q(m);
                    f = T(e, f);
                    h &&= T(g, h);
                    l &&= T(k, l);
                    v = T(t, v);
                    var w = db(m);
                    cb(w, function () {
                        ub(`Cannot construct ${m} due to unbound types`, [d]);
                    });
                    P([a, b, c], d ? [d] : [], (y) => {
                        y = y[0];
                        if (d) {
                            var B = y.dd;
                            var D = B.od;
                        } else D = $a.prototype;
                        y = ab(m, function (...Oa) {
                            if (Object.getPrototypeOf(this) !== I)
                                throw new R("Use 'new' to construct " + m);
                            if (void 0 === E.nd) throw new R(m + ' has no accessible constructor');
                            var wb = E.nd[Oa.length];
                            if (void 0 === wb)
                                throw new R(
                                    `Tried to invoke ctor of ${m} with invalid number of parameters (${Oa.length}) - expected (${Object.keys(E.nd).toString()}) parameters instead!`,
                                );
                            return wb.apply(this, Oa);
                        });
                        var I = Object.create(D, { constructor: { value: y } });
                        y.prototype = I;
                        var E = new eb(m, y, I, v, B, f, h, l);
                        if (E.hd) {
                            var ha;
                            (ha = E.hd).xd ?? (ha.xd = []);
                            E.hd.xd.push(E);
                        }
                        B = new lb(m, E, !0, !1, !1);
                        ha = new lb(m + '*', E, !1, !1, !1);
                        D = new lb(m + ' const*', E, !1, !0, !1);
                        Ua[a] = { pointerType: ha, Cd: D };
                        mb(w, y);
                        return [B, ha, D];
                    });
                },
                ja: (a, b, c, d, e, f) => {
                    var g = vb(b, c);
                    e = T(d, e);
                    P([], [a], (h) => {
                        h = h[0];
                        var k = `constructor ${h.name}`;
                        void 0 === h.dd.nd && (h.dd.nd = []);
                        if (void 0 !== h.dd.nd[b - 1])
                            throw new R(
                                `Cannot register multiple constructors with identical number of parameters (${
                                    b - 1
                                }) for class '${h.name}'! Overload resolution is currently only performed using the parameter count, not actual type info!`,
                            );
                        h.dd.nd[b - 1] = () => {
                            ub(`Cannot construct ${h.name} due to unbound types`, g);
                        };
                        P([], g, (l) => {
                            l.splice(1, 0, null);
                            h.dd.nd[b - 1] = zb(k, l, null, e, f);
                            return [];
                        });
                        return [];
                    });
                },
                q: (a, b, c, d, e, f, g, h, k) => {
                    var l = vb(c, d);
                    b = Q(b);
                    b = Ab(b);
                    f = T(e, f);
                    P([], [a], (m) => {
                        function t() {
                            ub(`Cannot call ${v} due to unbound types`, l);
                        }
                        m = m[0];
                        var v = `${m.name}.${b}`;
                        b.startsWith('@@') && (b = Symbol[b.substring(2)]);
                        h && m.dd.Md.push(b);
                        var w = m.dd.od,
                            y = w[b];
                        void 0 === y ||
                        (void 0 === y.fd && y.className !== m.name && y.pd === c - 2)
                            ? ((t.pd = c - 2), (t.className = m.name), (w[b] = t))
                            : (bb(w, b, v), (w[b].fd[c - 2] = t));
                        P([], l, (B) => {
                            B = zb(v, B, m, f, g, k);
                            void 0 === w[b].fd
                                ? ((B.pd = c - 2), (w[b] = B))
                                : (w[b].fd[c - 2] = B);
                            return [];
                        });
                        return [];
                    });
                },
                _b: (a) => O(a, Cb),
                ga: (a, b, c, d) => {
                    function e() {}
                    b = Q(b);
                    e.values = {};
                    O(a, {
                        name: b,
                        constructor: e,
                        fromWireType: function (f) {
                            return this.constructor.values[f];
                        },
                        toWireType: (f, g) => g.value,
                        ld: 8,
                        readValueFromPointer: Db(b, c, d),
                        jd: null,
                    });
                    cb(b, e);
                },
                D: (a, b, c) => {
                    var d = Eb(a);
                    b = Q(b);
                    a = d.constructor;
                    d = Object.create(d.constructor.prototype, {
                        value: { value: c },
                        constructor: { value: ab(`${d.name}_${b}`, function () {}) },
                    });
                    a.values[c] = d;
                    a[b] = d;
                },
                Ua: (a, b, c) => {
                    b = Q(b);
                    O(a, {
                        name: b,
                        fromWireType: (d) => d,
                        toWireType: (d, e) => e,
                        ld: 8,
                        readValueFromPointer: Fb(b, c),
                        jd: null,
                    });
                },
                V: (a, b, c, d, e, f, g) => {
                    var h = vb(b, c);
                    a = Q(a);
                    a = Ab(a);
                    e = T(d, e);
                    cb(
                        a,
                        function () {
                            ub(`Cannot call ${a} due to unbound types`, h);
                        },
                        b - 1,
                    );
                    P([], h, (k) => {
                        mb(a, zb(a, [k[0], null].concat(k.slice(1)), null, e, f, g), b - 1);
                        return [];
                    });
                },
                X: (a, b, c, d, e) => {
                    b = Q(b);
                    -1 === e && (e = 4294967295);
                    e = (h) => h;
                    if (0 === d) {
                        var f = 32 - 8 * c;
                        e = (h) => (h << f) >>> f;
                    }
                    var g = b.includes('unsigned')
                        ? function (h, k) {
                              return k >>> 0;
                          }
                        : function (h, k) {
                              return k;
                          };
                    O(a, {
                        name: b,
                        fromWireType: e,
                        toWireType: g,
                        ld: 8,
                        readValueFromPointer: Gb(b, c, 0 !== d),
                        jd: null,
                    });
                },
                H: (a, b, c) => {
                    function d(f) {
                        return new e(r.buffer, C[(f + 4) >> 2], C[f >> 2]);
                    }
                    var e = [
                        Int8Array,
                        Uint8Array,
                        Int16Array,
                        Uint16Array,
                        Int32Array,
                        Uint32Array,
                        Float32Array,
                        Float64Array,
                    ][b];
                    c = Q(c);
                    O(a, { name: c, fromWireType: d, ld: 8, readValueFromPointer: d }, { Kd: !0 });
                },
                $a: (a, b) => {
                    b = Q(b);
                    O(a, {
                        name: b,
                        fromWireType: function (c) {
                            for (var d = C[c >> 2], e = c + 4, f, g = e, h = 0; h <= d; ++h) {
                                var k = e + h;
                                if (h == d || 0 == u[k])
                                    (g = g ? Ga(u, g, k - g) : ''),
                                        void 0 === f
                                            ? (f = g)
                                            : ((f += String.fromCharCode(0)), (f += g)),
                                        (g = k + 1);
                            }
                            U(c);
                            return f;
                        },
                        toWireType: function (c, d) {
                            d instanceof ArrayBuffer && (d = new Uint8Array(d));
                            var e,
                                f = 'string' == typeof d;
                            if (
                                !(
                                    f ||
                                    d instanceof Uint8Array ||
                                    d instanceof Uint8ClampedArray ||
                                    d instanceof Int8Array
                                )
                            )
                                throw new R('Cannot pass non-string to std::string');
                            if (f)
                                for (var g = (e = 0); g < d.length; ++g) {
                                    var h = d.charCodeAt(g);
                                    127 >= h
                                        ? e++
                                        : 2047 >= h
                                          ? (e += 2)
                                          : 55296 <= h && 57343 >= h
                                            ? ((e += 4), ++g)
                                            : (e += 3);
                                }
                            else e = d.length;
                            g = bc(4 + e + 1);
                            h = g + 4;
                            C[g >> 2] = e;
                            if (f) Hb(d, h, e + 1);
                            else if (f)
                                for (f = 0; f < e; ++f) {
                                    var k = d.charCodeAt(f);
                                    if (255 < k)
                                        throw (
                                            (U(h),
                                            new R(
                                                'String has UTF-16 code units that do not fit in 8 bits',
                                            ))
                                        );
                                    u[h + f] = k;
                                }
                            else for (f = 0; f < e; ++f) u[h + f] = d[f];
                            null !== c && c.push(U, g);
                            return g;
                        },
                        ld: 8,
                        readValueFromPointer: Ja,
                        jd(c) {
                            U(c);
                        },
                    });
                },
                oa: (a, b, c) => {
                    c = Q(c);
                    if (2 === b) {
                        var d = Jb;
                        var e = Kb;
                        var f = Lb;
                        var g = (h) => z[h >> 1];
                    } else 4 === b && ((d = Mb), (e = Nb), (f = Ob), (g = (h) => C[h >> 2]));
                    O(a, {
                        name: c,
                        fromWireType: (h) => {
                            for (var k = C[h >> 2], l, m = h + 4, t = 0; t <= k; ++t) {
                                var v = h + 4 + t * b;
                                if (t == k || 0 == g(v))
                                    (m = d(m, v - m)),
                                        void 0 === l
                                            ? (l = m)
                                            : ((l += String.fromCharCode(0)), (l += m)),
                                        (m = v + b);
                            }
                            U(h);
                            return l;
                        },
                        toWireType: (h, k) => {
                            if ('string' != typeof k)
                                throw new R(`Cannot pass non-string to C++ string type ${c}`);
                            var l = f(k),
                                m = bc(4 + l + b);
                            C[m >> 2] = l / b;
                            e(k, m + 4, l + b);
                            null !== h && h.push(U, m);
                            return m;
                        },
                        ld: 8,
                        readValueFromPointer: Ja,
                        jd(h) {
                            U(h);
                        },
                    });
                },
                xa: (a, b, c, d, e, f) => {
                    Ha[a] = { name: Q(b), wd: T(c, d), md: T(e, f), Ad: [] };
                },
                $b: (a, b, c, d, e, f, g, h, k, l) => {
                    Ha[a].Ad.push({
                        Ed: Q(b),
                        Jd: c,
                        Hd: T(d, e),
                        Id: f,
                        Pd: g,
                        Od: T(h, k),
                        Qd: l,
                    });
                },
                bb: (a, b) => {
                    b = Q(b);
                    O(a, { Sd: !0, name: b, ld: 0, fromWireType: () => {}, toWireType: () => {} });
                },
                tb: (a, b, c) => u.copyWithin(a, b, b + c),
                eb: () => {},
                cb: () => {
                    throw Infinity;
                },
                fb: (a, b) => {
                    Pb[a] && (clearTimeout(Pb[a].id), delete Pb[a]);
                    if (!b) return 0;
                    var c = setTimeout(() => {
                        delete Pb[a];
                        Qb(() => cc(a, performance.now()));
                    }, b);
                    Pb[a] = { id: c, Td: b };
                    return 0;
                },
                lb: (a, b, c, d) => {
                    var e = new Date().getFullYear(),
                        f = new Date(e, 0, 1).getTimezoneOffset();
                    e = new Date(e, 6, 1).getTimezoneOffset();
                    C[a >> 2] = 60 * Math.max(f, e);
                    A[b >> 2] = Number(f != e);
                    b = (g) => {
                        var h = Math.abs(g);
                        return `UTC${0 <= g ? '-' : '+'}${String(Math.floor(h / 60)).padStart(2, '0')}${String(h % 60).padStart(2, '0')}`;
                    };
                    a = b(f);
                    b = b(e);
                    e < f ? (Hb(a, c, 17), Hb(b, d, 17)) : (Hb(a, d, 17), Hb(b, c, 17));
                },
                Ob: function (a, b, c, d) {
                    if (!(0 <= a && 3 >= a)) return 28;
                    a = Math.round(1e6 * (0 === a ? Date.now() : performance.now()));
                    ya = [
                        a >>> 0,
                        ((J = a),
                        1 <= +Math.abs(J)
                            ? 0 < J
                                ? +Math.floor(J / 4294967296) >>> 0
                                : ~~+Math.ceil((J - +(~~J >>> 0)) / 4294967296) >>> 0
                            : 0),
                    ];
                    A[d >> 2] = ya[0];
                    A[(d + 4) >> 2] = ya[1];
                    return 0;
                },
                jb: () => Date.now(),
                Ea: (a) => q(a ? Ga(u, a) : ''),
                ra: () => performance.now(),
                hb: (a) => {
                    var b = u.length;
                    a >>>= 0;
                    if (2147483648 < a) return !1;
                    for (var c = 1; 4 >= c; c *= 2) {
                        var d = b * (1 + 0.2 / c);
                        d = Math.min(d, a + 100663296);
                        a: {
                            d =
                                ((Math.min(2147483648, 65536 * Math.ceil(Math.max(a, d) / 65536)) -
                                    la.buffer.byteLength +
                                    65535) /
                                    65536) |
                                0;
                            try {
                                la.grow(d);
                                pa();
                                var e = 1;
                                break a;
                            } catch (f) {}
                            e = void 0;
                        }
                        if (e) return !0;
                    }
                    return !1;
                },
                nb: (a, b) => {
                    var c = 0;
                    Tb().forEach((d, e) => {
                        var f = b + c;
                        e = C[(a + 4 * e) >> 2] = f;
                        for (f = 0; f < d.length; ++f) r[e++] = d.charCodeAt(f);
                        r[e] = 0;
                        c += d.length + 1;
                    });
                    return 0;
                },
                ob: (a, b) => {
                    var c = Tb();
                    C[a >> 2] = c.length;
                    var d = 0;
                    c.forEach((e) => (d += e.length + 1));
                    C[b >> 2] = d;
                    return 0;
                },
                wb: (a) => {
                    throw new za(a);
                },
                fa: () => 52,
                Ga: () => 52,
                Pb: function () {
                    return 70;
                },
                Fa: (a, b, c, d) => {
                    for (var e = 0, f = 0; f < c; f++) {
                        var g = C[b >> 2],
                            h = C[(b + 4) >> 2];
                        b += 8;
                        for (var k = 0; k < h; k++) {
                            var l = u[g + k],
                                m = Ub[a];
                            0 === l || 10 === l
                                ? ((1 === a ? ka : q)(Ga(m)), (m.length = 0))
                                : m.push(l);
                        }
                        e += h;
                    }
                    C[d >> 2] = e;
                    return 0;
                },
                Da: dc,
                _: ec,
                M: fc,
                La: gc,
                Ka: hc,
                G: ic,
                Ma: jc,
                la: kc,
                na: lc,
                Za: mc,
                c: nc,
                _a: oc,
                O: pc,
                T: qc,
                ya: rc,
                d: sc,
                Q: tc,
                y: uc,
                Wa: vc,
                P: wc,
                qa: xc,
                b: yc,
                I: zc,
                Ba: Ac,
                l: Bc,
                Ja: Cc,
                R: Dc,
                L: Ec,
                $: Fc,
                Ya: Gc,
                Oa: Hc,
                r: Ic,
                va: Jc,
                Ca: Kc,
                Zb: Lc,
                Na: Mc,
                W: Nc,
                w: Oc,
                Ub: Pc,
                u: Qc,
                da: Rc,
                Tb: Sc,
                ba: Tc,
                t: Uc,
                Xa: Vc,
                ma: Wc,
                Pa: Xc,
                ia: Yc,
                yb: Zc,
                Fb: $c,
                Jb: ad,
                Cb: bd,
                Db: cd,
                Bb: dd,
                zb: ed,
                Eb: fd,
                Ab: gd,
                g: hd,
                m: jd,
                ea: kd,
                v: ld,
                f: md,
                ua: nd,
                Yb: od,
                E: pd,
                ca: qd,
                K: rd,
                Va: sd,
                Z: td,
                e: ud,
                U: vd,
                aa: wd,
                S: xd,
                N: yd,
                j: zd,
                Xb: Ad,
                wa: Bd,
                k: Cd,
                ta: Dd,
                Vb: Ed,
                za: Fd,
                ka: Gd,
                x: Hd,
                Wb: Id,
                z: Jd,
                Ta: Kd,
                Sb: Ld,
                A: Md,
                Aa: Nd,
                pa: Od,
                J: Pd,
                F: Qd,
                Sa: Rd,
                Ra: Sd,
                ha: Td,
                Qa: Ud,
                Kb: Vd,
                Mb: Wd,
                Gb: Xd,
                Nb: Yd,
                Ib: Zd,
                Hb: $d,
                Lb: ae,
                s: (a) => a,
                db: (a) => {
                    throw new za(a);
                },
                ib: (a, b) => {
                    Wb(u.subarray(a, a + b));
                    return 0;
                },
            },
            X;
        (async function () {
            F++;
            var a = { a: be };
            ua ??= ta('codeengine_wasm.wasm')
                ? 'codeengine_wasm.wasm'
                : n.locateFile
                  ? n.locateFile('codeengine_wasm.wasm', p)
                  : p + 'codeengine_wasm.wasm';
            try {
                var b = await xa(a);
                X = b.instance.exports;
                la = X.ac;
                pa();
                ob = X.hc;
                ra.unshift(X.bc);
                F--;
                0 == F && G && ((a = G), (G = null), a());
                return b;
            } catch (c) {
                ba(c);
            }
        })();
        var sb = (a) => (sb = X.cc)(a);
        n.__ZdlPv = (a) => (n.__ZdlPv = X.dc)(a);
        var bc = (n._malloc = (a) => (bc = n._malloc = X.ec)(a));
        n.__ZdaPv = (a) => (n.__ZdaPv = X.fc)(a);
        var U = (n._free = (a) => (U = n._free = X.gc)(a));
        n._emscripten_builtin_malloc = (a) => (n._emscripten_builtin_malloc = X.ic)(a);
        var cc = (a, b) => (cc = X.jc)(a, b);
        n._strndup = (a, b) => (n._strndup = X.kc)(a, b);
        n.__ZdaPvm = (a, b) => (n.__ZdaPvm = X.lc)(a, b);
        n.__ZdlPvm = (a, b) => (n.__ZdlPvm = X.mc)(a, b);
        n.__Znaj = (a) => (n.__Znaj = X.nc)(a);
        n.__ZnajSt11align_val_t = (a, b) => (n.__ZnajSt11align_val_t = X.oc)(a, b);
        n.__Znwj = (a) => (n.__Znwj = X.pc)(a);
        n.__ZnwjSt11align_val_t = (a, b) => (n.__ZnwjSt11align_val_t = X.qc)(a, b);
        n.___libc_calloc = (a, b) => (n.___libc_calloc = X.rc)(a, b);
        n.___libc_free = (a) => (n.___libc_free = X.sc)(a);
        n.___libc_malloc = (a) => (n.___libc_malloc = X.tc)(a);
        n.___libc_realloc = (a, b) => (n.___libc_realloc = X.uc)(a, b);
        n._emscripten_builtin_calloc = (a, b) => (n._emscripten_builtin_calloc = X.vc)(a, b);
        n._emscripten_builtin_free = (a) => (n._emscripten_builtin_free = X.wc)(a);
        n._emscripten_builtin_realloc = (a, b) => (n._emscripten_builtin_realloc = X.xc)(a, b);
        n._malloc_size = (a) => (n._malloc_size = X.yc)(a);
        n._malloc_usable_size = (a) => (n._malloc_usable_size = X.zc)(a);
        n._reallocf = (a, b) => (n._reallocf = X.Ac)(a, b);
        var W = (a, b) => (W = X.Bc)(a, b),
            L = (a) => (L = X.Cc)(a),
            Y = (a) => (Y = X.Dc)(a),
            Z = () => (Z = X.Ec)(),
            ac = (a) => (ac = X.Fc)(a),
            Zb = (a) => (Zb = X.Gc)(a),
            Da = (a, b, c) => (Da = X.Hc)(a, b, c),
            $b = (a) => ($b = X.Ic)(a),
            ce = (n.dynCall_iij = (a, b, c, d) => (ce = n.dynCall_iij = X.Jc)(a, b, c, d)),
            de = (n.dynCall_vij = (a, b, c, d) => (de = n.dynCall_vij = X.Kc)(a, b, c, d)),
            ee = (n.dynCall_j = (a) => (ee = n.dynCall_j = X.Lc)(a)),
            fe = (n.dynCall_viij = (a, b, c, d, e) => (fe = n.dynCall_viij = X.Mc)(a, b, c, d, e)),
            ge = (n.dynCall_vijjjjii = (a, b, c, d, e, f, g, h, k, l, m, t) =>
                (ge = n.dynCall_vijjjjii = X.Nc)(a, b, c, d, e, f, g, h, k, l, m, t)),
            he = (n.dynCall_viiijjj = (a, b, c, d, e, f, g, h, k, l) =>
                (he = n.dynCall_viiijjj = X.Oc)(a, b, c, d, e, f, g, h, k, l)),
            ie = (n.dynCall_iiijiiiiiii = (a, b, c, d, e, f, g, h, k, l, m, t) =>
                (ie = n.dynCall_iiijiiiiiii = X.Pc)(a, b, c, d, e, f, g, h, k, l, m, t)),
            je = (n.dynCall_vijff = (a, b, c, d, e, f) =>
                (je = n.dynCall_vijff = X.Qc)(a, b, c, d, e, f)),
            ke = (n.dynCall_viji = (a, b, c, d, e) => (ke = n.dynCall_viji = X.Rc)(a, b, c, d, e)),
            le = (n.dynCall_iijjj = (a, b, c, d, e, f, g, h) =>
                (le = n.dynCall_iijjj = X.Sc)(a, b, c, d, e, f, g, h)),
            me = (n.dynCall_iiiiij = (a, b, c, d, e, f, g) =>
                (me = n.dynCall_iiiiij = X.Tc)(a, b, c, d, e, f, g)),
            ne = (n.dynCall_jiji = (a, b, c, d, e) => (ne = n.dynCall_jiji = X.Uc)(a, b, c, d, e)),
            oe = (n.dynCall_jii = (a, b, c) => (oe = n.dynCall_jii = X.Vc)(a, b, c)),
            pe = (n.dynCall_viijj = (a, b, c, d, e, f, g) =>
                (pe = n.dynCall_viijj = X.Wc)(a, b, c, d, e, f, g)),
            qe = (n.dynCall_iiiji = (a, b, c, d, e, f) =>
                (qe = n.dynCall_iiiji = X.Xc)(a, b, c, d, e, f)),
            re = (n.dynCall_iijijiji = (a, b, c, d, e, f, g, h, k, l, m) =>
                (re = n.dynCall_iijijiji = X.Yc)(a, b, c, d, e, f, g, h, k, l, m));
        n.dynCall_viijii = (a, b, c, d, e, f, g) => (n.dynCall_viijii = X.Zc)(a, b, c, d, e, f, g);
        n.dynCall_ji = (a, b) => (n.dynCall_ji = X._c)(a, b);
        n.dynCall_iiiiijj = (a, b, c, d, e, f, g, h, k) =>
            (n.dynCall_iiiiijj = X.$c)(a, b, c, d, e, f, g, h, k);
        n.dynCall_iiiiiijj = (a, b, c, d, e, f, g, h, k, l) =>
            (n.dynCall_iiiiiijj = X.ad)(a, b, c, d, e, f, g, h, k, l);
        function nc(a, b) {
            var c = Z();
            try {
                return S(a)(b);
            } catch (d) {
                Y(c);
                if (d !== d + 0) throw d;
                W(1, 0);
            }
        }
        function Qd(a, b, c, d, e, f, g, h, k, l, m) {
            var t = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m);
            } catch (v) {
                Y(t);
                if (v !== v + 0) throw v;
                W(1, 0);
            }
        }
        function jd(a, b) {
            var c = Z();
            try {
                S(a)(b);
            } catch (d) {
                Y(c);
                if (d !== d + 0) throw d;
                W(1, 0);
            }
        }
        function Bc(a, b, c, d, e) {
            var f = Z();
            try {
                return S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function sc(a, b, c) {
            var d = Z();
            try {
                return S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function ud(a, b, c, d) {
            var e = Z();
            try {
                S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function hd(a) {
            var b = Z();
            try {
                S(a)();
            } catch (c) {
                Y(b);
                if (c !== c + 0) throw c;
                W(1, 0);
            }
        }
        function Qc(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                return S(a)(b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function md(a, b, c) {
            var d = Z();
            try {
                S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function Cd(a, b, c, d, e, f) {
            var g = Z();
            try {
                S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function zd(a, b, c, d, e) {
            var f = Z();
            try {
                S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function yc(a, b, c, d) {
            var e = Z();
            try {
                return S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function Ic(a, b, c, d, e, f) {
            var g = Z();
            try {
                return S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function Oc(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                return S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function rd(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function Pd(a, b, c, d, e, f, g, h, k, l) {
            var m = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l);
            } catch (t) {
                Y(m);
                if (t !== t + 0) throw t;
                W(1, 0);
            }
        }
        function vd(a, b, c, d, e) {
            var f = Z();
            try {
                S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Jd(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                S(a)(b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function fc(a, b) {
            var c = Z();
            try {
                return S(a)(b);
            } catch (d) {
                Y(c);
                if (d !== d + 0) throw d;
                W(1, 0);
            }
        }
        function Dc(a, b, c, d, e, f) {
            var g = Z();
            try {
                return S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function pc(a, b, c) {
            var d = Z();
            try {
                return S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function Hd(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function Tc(a, b, c, d, e, f, g, h, k, l, m, t, v, w) {
            var y = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m, t, v, w);
            } catch (B) {
                Y(y);
                if (B !== B + 0) throw B;
                W(1, 0);
            }
        }
        function xc(a, b, c, d, e, f) {
            var g = Z();
            try {
                return S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function ic(a, b, c) {
            var d = Z();
            try {
                return S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function uc(a, b, c, d, e) {
            var f = Z();
            try {
                return S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Md(a, b, c, d, e, f, g, h, k) {
            var l = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k);
            } catch (m) {
                Y(l);
                if (m !== m + 0) throw m;
                W(1, 0);
            }
        }
        function dc(a, b, c) {
            var d = Z();
            try {
                return S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function oc(a, b, c) {
            var d = Z();
            try {
                return S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function Uc(a, b, c, d, e, f, g, h, k) {
            var l = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k);
            } catch (m) {
                Y(l);
                if (m !== m + 0) throw m;
                W(1, 0);
            }
        }
        function pd(a, b, c, d) {
            var e = Z();
            try {
                S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function tc(a, b, c, d) {
            var e = Z();
            try {
                return S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function Od(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function wc(a, b, c, d, e) {
            var f = Z();
            try {
                return S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Kc(a, b, c, d, e, f, g, h, k, l, m, t, v, w, y) {
            var B = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m, t, v, w, y);
            } catch (D) {
                Y(B);
                if (D !== D + 0) throw D;
                W(1, 0);
            }
        }
        function wd(a, b, c, d, e) {
            var f = Z();
            try {
                S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Ac(a, b, c, d, e, f, g, h, k, l, m) {
            var t = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m);
            } catch (v) {
                Y(t);
                if (v !== v + 0) throw v;
                W(1, 0);
            }
        }
        function kd(a, b, c) {
            var d = Z();
            try {
                S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function Rc(a, b, c, d, e, f, g, h, k) {
            var l = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k);
            } catch (m) {
                Y(l);
                if (m !== m + 0) throw m;
                W(1, 0);
            }
        }
        function ld(a, b, c) {
            var d = Z();
            try {
                S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function Nd(a, b, c, d, e, f, g, h, k, l) {
            var m = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l);
            } catch (t) {
                Y(m);
                if (t !== t + 0) throw t;
                W(1, 0);
            }
        }
        function Fd(a, b, c, d, e, f, g, h, k, l, m, t, v) {
            var w = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t, v);
            } catch (y) {
                Y(w);
                if (y !== y + 0) throw y;
                W(1, 0);
            }
        }
        function rc(a, b, c, d, e, f) {
            var g = Z();
            try {
                return S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function mc(a, b, c, d) {
            var e = Z();
            try {
                return S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function qc(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                return S(a)(b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function Gc(a, b, c, d, e, f, g, h, k) {
            var l = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k);
            } catch (m) {
                Y(l);
                if (m !== m + 0) throw m;
                W(1, 0);
            }
        }
        function ec(a, b, c, d, e, f) {
            var g = Z();
            try {
                return S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function lc(a, b, c, d, e) {
            var f = Z();
            try {
                return S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Vc(a, b, c, d, e, f, g, h, k, l) {
            var m = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l);
            } catch (t) {
                Y(m);
                if (t !== t + 0) throw t;
                W(1, 0);
            }
        }
        function Wc(a, b, c, d, e, f, g, h, k, l, m) {
            var t = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m);
            } catch (v) {
                Y(t);
                if (v !== v + 0) throw v;
                W(1, 0);
            }
        }
        function Bd(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function vc(a, b, c, d, e, f) {
            var g = Z();
            try {
                return S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function Fc(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                return S(a)(b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function Ec(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                return S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function qd(a, b, c, d, e) {
            var f = Z();
            try {
                S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function zc(a, b, c, d, e) {
            var f = Z();
            try {
                return S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Lc(a, b, c, d, e, f, g, h, k) {
            var l = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k);
            } catch (m) {
                Y(l);
                if (m !== m + 0) throw m;
                W(1, 0);
            }
        }
        function Jc(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                return S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function od(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function Ad(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                S(a)(b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function Id(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function Nc(a, b, c, d, e, f, g, h, k, l) {
            var m = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l);
            } catch (t) {
                Y(m);
                if (t !== t + 0) throw t;
                W(1, 0);
            }
        }
        function Ed(a, b, c, d, e, f, g, h, k, l) {
            var m = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l);
            } catch (t) {
                Y(m);
                if (t !== t + 0) throw t;
                W(1, 0);
            }
        }
        function sd(a, b, c, d, e, f, g, h, k, l, m) {
            var t = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m);
            } catch (v) {
                Y(t);
                if (v !== v + 0) throw v;
                W(1, 0);
            }
        }
        function Pc(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                return S(a)(b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function Kd(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function Sc(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function kc(a, b, c, d) {
            var e = Z();
            try {
                return S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function Ld(a, b, c, d, e, f, g, h, k, l, m, t, v) {
            var w = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t, v);
            } catch (y) {
                Y(w);
                if (y !== y + 0) throw y;
                W(1, 0);
            }
        }
        function Rd(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function Gd(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                S(a)(b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function Sd(a, b, c, d, e, f, g, h, k, l, m, t, v) {
            var w = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t, v);
            } catch (y) {
                Y(w);
                if (y !== y + 0) throw y;
                W(1, 0);
            }
        }
        function Ud(a, b, c, d, e, f, g, h, k, l, m, t, v, w, y, B, D) {
            var I = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t, v, w, y, B, D);
            } catch (E) {
                Y(I);
                if (E !== E + 0) throw E;
                W(1, 0);
            }
        }
        function nd(a, b, c, d) {
            var e = Z();
            try {
                S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function Xc(a, b, c, d, e, f, g, h, k, l, m) {
            var t = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m);
            } catch (v) {
                Y(t);
                if (v !== v + 0) throw v;
                W(1, 0);
            }
        }
        function td(a, b, c, d, e) {
            var f = Z();
            try {
                S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function xd(a, b, c, d, e, f) {
            var g = Z();
            try {
                S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function Hc(a, b, c, d, e, f, g, h, k) {
            var l = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k);
            } catch (m) {
                Y(l);
                if (m !== m + 0) throw m;
                W(1, 0);
            }
        }
        function Mc(a, b, c, d, e, f, g, h, k, l, m, t, v) {
            var w = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m, t, v);
            } catch (y) {
                Y(w);
                if (y !== y + 0) throw y;
                W(1, 0);
            }
        }
        function jc(a, b, c, d, e) {
            var f = Z();
            try {
                return S(a)(b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Dd(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                S(a)(b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function gc(a, b, c) {
            var d = Z();
            try {
                return S(a)(b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function hc(a, b, c, d) {
            var e = Z();
            try {
                return S(a)(b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function yd(a, b, c, d, e, f, g, h, k, l) {
            var m = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l);
            } catch (t) {
                Y(m);
                if (t !== t + 0) throw t;
                W(1, 0);
            }
        }
        function Cc(a, b, c, d, e, f) {
            var g = Z();
            try {
                return S(a)(b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function Yc(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                return S(a)(b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function Td(a, b, c, d, e, f, g, h, k, l, m, t, v, w, y, B) {
            var D = Z();
            try {
                S(a)(b, c, d, e, f, g, h, k, l, m, t, v, w, y, B);
            } catch (I) {
                Y(D);
                if (I !== I + 0) throw I;
                W(1, 0);
            }
        }
        function Yd(a, b, c, d) {
            var e = Z();
            try {
                de(a, b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function Wd(a, b, c, d, e) {
            var f = Z();
            try {
                fe(a, b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function ae(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                ge(a, b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function Vd(a, b, c, d, e, f, g, h, k, l) {
            var m = Z();
            try {
                he(a, b, c, d, e, f, g, h, k, l);
            } catch (t) {
                Y(m);
                if (t !== t + 0) throw t;
                W(1, 0);
            }
        }
        function ad(a, b, c, d, e, f, g, h, k, l, m, t) {
            var v = Z();
            try {
                return ie(a, b, c, d, e, f, g, h, k, l, m, t);
            } catch (w) {
                Y(v);
                if (w !== w + 0) throw w;
                W(1, 0);
            }
        }
        function Zd(a, b, c, d, e, f) {
            var g = Z();
            try {
                je(a, b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function $d(a, b, c, d, e) {
            var f = Z();
            try {
                ke(a, b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function Xd(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                pe(a, b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        function $c(a, b, c, d, e, f) {
            var g = Z();
            try {
                return qe(a, b, c, d, e, f);
            } catch (h) {
                Y(g);
                if (h !== h + 0) throw h;
                W(1, 0);
            }
        }
        function fd(a, b, c) {
            var d = Z();
            try {
                return oe(a, b, c);
            } catch (e) {
                Y(d);
                if (e !== e + 0) throw e;
                W(1, 0);
            }
        }
        function cd(a, b, c, d, e, f, g, h, k, l, m) {
            var t = Z();
            try {
                return re(a, b, c, d, e, f, g, h, k, l, m);
            } catch (v) {
                Y(t);
                if (v !== v + 0) throw v;
                W(1, 0);
            }
        }
        function bd(a, b, c, d) {
            var e = Z();
            try {
                return ce(a, b, c, d);
            } catch (f) {
                Y(e);
                if (f !== f + 0) throw f;
                W(1, 0);
            }
        }
        function dd(a, b, c, d, e, f, g, h) {
            var k = Z();
            try {
                return le(a, b, c, d, e, f, g, h);
            } catch (l) {
                Y(k);
                if (l !== l + 0) throw l;
                W(1, 0);
            }
        }
        function gd(a, b, c, d, e) {
            var f = Z();
            try {
                return ne(a, b, c, d, e);
            } catch (g) {
                Y(f);
                if (g !== g + 0) throw g;
                W(1, 0);
            }
        }
        function ed(a) {
            var b = Z();
            try {
                return ee(a);
            } catch (c) {
                Y(b);
                if (c !== c + 0) throw c;
                W(1, 0);
            }
        }
        function Zc(a, b, c, d, e, f, g) {
            var h = Z();
            try {
                return me(a, b, c, d, e, f, g);
            } catch (k) {
                Y(h);
                if (k !== k + 0) throw k;
                W(1, 0);
            }
        }
        var se;
        G = function te() {
            se || ue();
            se || (G = te);
        };
        function ue() {
            if (!(0 < F)) {
                for (; 0 < qa.length; ) qa.shift()(n);
                if (!(0 < F || se || ((se = !0), (n.calledRun = !0), ma))) {
                    for (; 0 < ra.length; ) ra.shift()(n);
                    for (aa(n); 0 < sa.length; ) sa.shift()(n);
                }
            }
        }
        ue();
        moduleRtn = ca;

        return moduleRtn;
    };
})();
if (typeof exports === 'object' && typeof module === 'object') {
    module.exports = SmartCodeEngine;
    // This default export looks redundant, but it allows TS to import this
    // commonjs style module.
    module.exports.default = SmartCodeEngine;
} else if (typeof define === 'function' && define['amd']) define([], () => SmartCodeEngine);
