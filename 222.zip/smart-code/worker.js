/* eslint-disable */

const signature =
    '312dc4f37f2fb11f500770d41e3b760d95c26b07eb51617750f45c6659883ab3a0730d9e729e38d3230918d9baed67886f0643693cab56d891ce73bb832e906a80fa080f8472aac3fb08f77bd6acffb8b7ce47f373c1e08c8e99a41706dbd06e7057aacf1cc3c9b8738a336cf62af809038baf8d80f5504fd3dac19ca6b43faa';

const ctx = self;

const activatorSelectorEnum = {
    firstSession: 'firstSession',
    secondSession: 'secondSession',
}

const getTextFields = (result) => {
    // vendor have not provided a type for scanned data
    const data = [];
    const co = result.ObjectsBegin();

    for (; !co.Equals(result.ObjectsEnd()); co.Advance()) {
        const code_object = co.GetValue();
        const object_data = { type: code_object.GetTypeStr(), attributes: {} };
        const tf = code_object.FieldsBegin();

        for (; !tf.Equals(code_object.FieldsEnd()); tf.Advance()) {
            // const key = tf.GetKey();
            const code_field = tf.GetValue();
            const code_field_name = code_field.Name();
            let value_binary = '';
            let value_string = '';

            if (code_field.HasBinaryRepresentation()) {
                value_binary = code_field.GetBinaryRepresentation().GetBase64String();
            }

            if (code_field.HasOcrStringRepresentation())
                value_string = code_field.GetOcrString().GetFirstString();

            object_data[code_field_name] = {
                name: code_field_name,
                value_binary,
                value_string,
                isAccepted: code_field.IsAccepted(),
            };
        }
        // attr

        const start = code_object.AttributesBegin();
        const end = code_object.AttributesEnd();

        for (; !start.Equals(end); start.Advance()) {
            const attrKey = start.GetKey();

            const attrValue = start.GetValue();

            object_data.attributes[attrKey] = attrValue;
        }

        data.push(object_data);
    }

    return data;
};

(async () => {
    let engine;
    let firstSession;
    let secondSession;
    let currentDocType = 'barcode';

    const EngineConfig = {
        mode: 'default',
        signature,
    };

    postMessage({
        requestType: 'wasmEvent',
        data: { type: 'started' },
    });

    let SE;

    const initSmartEngine = async () => {
        ctx.importScripts('./codeengine_wasm.js');

        const wasmFilePath = {
            mainScriptUrlOrBlob: './codeengine_wasm.js',
            locateFile: (file) => `./${file}`,
        };

        return ctx.SmartCodeEngine(wasmFilePath);
    };

    try {
        SE = await initSmartEngine();
    } catch (e) {
        throw new Error('Не удалось проинициализировать SmartEngine');
    }

    try {
        // eslint-disable-next-line new-cap
        engine = new SE.CodeEngine(false);
    } catch (e) {
        postMessage({
            requestType: 'wasmEvent',
            data: {
                type: 'wasmError',
                data: `Create engine error ${SE.printExceptionMessage(e)}`,
            },
        });
        throw new Error(`Create engine ${SE.printExceptionMessage(e)}`);
    }

    async function createFirstSession(docType) {
        try {
            const sessionSettings = engine.GetDefaultSessionSettings();

            if (
                docType === 'barcode' &&
                engine.IsEngineAvailable(SE.CodeEngineType.CodeEngine_Barcode)
            ) {
                const engineName = SE.ToString(SE.EngineSettingsGroup.Barcode);

                sessionSettings.SetOption(`${engineName}.enabled`, 'true');
                sessionSettings.SetOption(`${engineName}.COMMON.enabled`, 'true');
                sessionSettings.SetOption(`${engineName}.maxAllowedCodes`, '99');
                sessionSettings.SetOption(`${engineName}.roiDetectionMode`, 'anywhere');
            }

            if (
                docType === 'card' &&
                engine.IsEngineAvailable(SE.CodeEngineType.CodeEngine_BankCard)
            ) {
                const engineName = SE.ToString(SE.EngineSettingsGroup.Card);

                sessionSettings.SetOption(`${engineName}.enabled`, 'true');
            }

            if (
                docType === 'phone' &&
                engine.IsEngineAvailable(SE.CodeEngineType.CodeEngine_CodeTextLine)
            ) {
                // Setting option to enable phone number recognition
                const engineName = SE.ToString(SE.EngineSettingsGroup.CodeTextLine);

                sessionSettings.SetOption(`${engineName}.enabled`, 'true');
                sessionSettings.SetOption(`${engineName}.phone_number.enabled`, 'true');
            }

            if (docType === 'universalPay') {
                sessionSettings.SetOption('global.workflow', 'universalPay');
                sessionSettings.SetOption('global.universalPay.collectNonPaymentBarcodes', 'true');
                sessionSettings.SetOption('barcode.enabled', 'true');
                sessionSettings.SetOption('barcode.feedMode', 'sequence');
                sessionSettings.SetOption('barcode.maxAllowedCodes', '1');
                sessionSettings.SetOption('barcode.smartPaymentBarDecoding', 'true');
                sessionSettings.SetOption('barcode.preset.URL.protocols', 'http|https|alfabank|aid');
                sessionSettings.SetOption('barcode.QR_CODE.enabled', 'true');
                sessionSettings.SetOption('barcode.AZTEC.enabled', 'true');
                sessionSettings.SetOption('barcode.DATA_MATRIX.enabled', 'true');
                sessionSettings.SetOption('barcode.preset', 'URL|PAYMENT');
                sessionSettings.SetOption('bank_card.enabled', 'true');
                sessionSettings.SetOption('code_text_line.enabled', 'true');
                sessionSettings.SetOption('code_text_line.phone_number.enabled', 'true');
            }

            sessionSettings.SetOption('global.sessionTimeout', '20.0');

            if (docType) {
                currentDocType = docType;
            }

            firstSession = await engine.SpawnSession(sessionSettings, EngineConfig.signature);

            const activationCode = firstSession.GetActivationRequest();

            postMessage({
                requestType: 'activation',
                code: activationCode,
                session: activatorSelectorEnum.firstSession
            });
        } catch (e) {
            let data = e;

            try {
                data = SE.printExceptionMessage(e);
            } catch (error) {
                /* empty */
            }

            // eslint-disable-next-line no-console
            console.error(data);

            postMessage({
                requestType: 'wasmEvent',
                data: { type: 'wasmError', data },
            });
        }
    }

    async function createSecondSession() {
        try {
            const secondSessionSettings = engine.GetDefaultSessionSettings();

            secondSessionSettings.SetOption('global.sessionTimeout', '5.0');

            secondSessionSettings.SetOption('payment_details.enabled', 'true');
            secondSessionSettings.SetOption('payment_details.captureMode', 'mobile');

            secondSession = await engine.SpawnSession(secondSessionSettings, EngineConfig.signature);

            const activationCode = secondSession.GetActivationRequest();

            postMessage({
                requestType: 'secondSessionActivation',
                code: activationCode,
                session: activatorSelectorEnum.secondSession
            });
        } catch (e) {
            let data = e;

            try {
                data = SE.printExceptionMessage(e);
            } catch (error) {
                /* empty */
            }

            console.error(data);

            postMessage({
                requestType: 'wasmEvent',
                data: { type: 'wasmError', data },
            });
        }
    }

    function resultObject(result, isManuallyUploaded, session) {
        return {
            isManuallyUploaded,
            requestType: 'result',
            docType: currentDocType,
            data: getTextFields(result),
            session,
        };
    }

    function recognizeFileByFirstSession(imageData, isManuallyUploaded) {
        const imgSrc = new SE.seImage(imageData);

        try {
            const result = firstSession.Process(imgSrc);

            const resultMessage = resultObject(result, isManuallyUploaded, activatorSelectorEnum.firstSession);

            imgSrc.delete();
            result.delete();

            return resultMessage;
        } catch (e) {
            postMessage({
                requestType: 'activationStatus',
                data: {
                    isActivated: firstSession.IsActivated(),
                },
            });
            const activationCode = firstSession.GetActivationRequest();

            postMessage({
                requestType: 'activation',
                code: activationCode,
                session: activatorSelectorEnum.firstSession
            });

            return null;
        }
    }

    const recognizeFileByFirstSessionAction = (imageData, isManuallyUploaded) => {
        postMessage('hui 1')
        const resultFile = recognizeFileByFirstSession(imageData, isManuallyUploaded);

        postMessage(resultFile);
    };

    const recognizeFileBySecondSessionAction = (imageData, isManuallyUploaded) => {
        postMessage('hui 2')
        const resultFile = recognizeFileBySecondSession(imageData, isManuallyUploaded);

        postMessage(resultFile);
    };

    function recognizeFileBySecondSession(imageData, isManuallyUploaded) {
        if (!secondSession) {
            return
        }

        const imgSrc = new SE.seImage(imageData);

        try {
            const result = secondSession.Process(imgSrc);

            const resultMessage = resultObject(result, isManuallyUploaded, activatorSelectorEnum.secondSession);

            imgSrc.delete();
            result.delete();

            return resultMessage;
        } catch (e) {
            postMessage({
                requestType: 'activationStatus',
                data: {
                    isActivated: secondSession.IsActivated(),
                },
            });
            const activationCode = secondSession.GetActivationRequest();

            postMessage({
                requestType: 'secondSessionActivation',
                code: activationCode,
                session: activatorSelectorEnum.secondSession
            });

            return null;
        }
    }

    postMessage({
        requestType: 'wasmEvent',
        data: {
            type: 'ready',
            version: SE.CodeEngineGetVersion(),
        },
    });
    ctx.onmessage = async (msg) => {
        switch (msg.data.requestType) {
            case 'file':
                recognizeFileBySecondSessionAction(msg.data.imageData, msg.data.isManuallyUploaded);
                recognizeFileByFirstSessionAction(msg.data.imageData, msg.data.isManuallyUploaded);
                break;

            case 'reset':
                firstSession.Reset();
                postMessage({ requestType: 'wasmEvent', data: { type: 'reset' } });
                break;

            case 'activationCode':
                const session = msg.data.session
                if (session === activatorSelectorEnum.firstSession) {
                    firstSession.Activate(msg.data.code);
                    if (firstSession.IsActivated()) {
                        postMessage({
                            requestType: 'activated',
                            data: {
                                version: SE.CodeEngineGetVersion(),
                            },
                        });

                        if (currentDocType === 'universalPay' && !secondSession) {
                            await createSecondSession();
                        }

                    } else {
                        postMessage({
                            requestType: 'activationError',
                        });
                    }
                } else if (session === activatorSelectorEnum.secondSession) {
                    secondSession.Activate(msg.data.code);
                    if (secondSession.IsActivated()) {
                        postMessage({
                            requestType: 'activated',
                            data: {
                                version: SE.CodeEngineGetVersion(),
                            },
                        });
                    } else {
                        postMessage({
                            requestType: 'activationError',
                        });
                    }
                }


                break;

            case 'createSession':
                await createFirstSession(msg.data.data);
                break;
        }
    };
})();
